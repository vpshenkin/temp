//>>built
define("dijit/form/nls/fi/ComboBox",({previousMessage:"Edelliset valinnat",nextMessage:"Lisää valintoja"}));
