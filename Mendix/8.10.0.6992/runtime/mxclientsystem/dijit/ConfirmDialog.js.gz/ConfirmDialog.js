//>>built
define("dijit/ConfirmDialog",["dojo/_base/declare","./Dialog","./_ConfirmDialogMixin"],function(_1,_2,_3){
return _1("dijit.ConfirmDialog",[_2,_3],{});
});
