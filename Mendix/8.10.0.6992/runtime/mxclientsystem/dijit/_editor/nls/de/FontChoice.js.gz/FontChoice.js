//>>built
define("dijit/_editor/nls/de/FontChoice",({fontSize:"Größe",fontName:"Schriftart",formatBlock:"Format",serif:"Serife","sans-serif":"Serifenlos",monospace:"Monospaceschrift",cursive:"Kursiv",fantasy:"Fantasie",noFormat:"Keine Angabe",p:"Absatz",h1:"Überschrift",h2:"Unterüberschrift",h3:"Unterunterüberschrift",pre:"Vorformatiert",1:"XXS",2:"XS",3:"S",4:"M",5:"L",6:"XL",7:"XXL"}));
