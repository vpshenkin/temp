//>>built
define("dijit/nls/es/common",({buttonOk:"Aceptar",buttonCancel:"Cancelar",buttonSave:"Guardar",itemClose:"Cerrar"}));
