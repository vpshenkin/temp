/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/on/throttle",["../throttle","../on"],function(_1,on){
return function(_2,_3){
return function(_4,_5){
return on(_4,_2,_1(_5,_3));
};
};
});
