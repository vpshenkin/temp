/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/mk/currency",{"HKD_displayName":"Хонгконшки долар","CHF_displayName":"Швајцарски Франк","JPY_symbol":"JPY","CAD_displayName":"Канадски долар","HKD_symbol":"HKD","CNY_displayName":"Кинески јуан","USD_symbol":"US$","AUD_displayName":"Австралиски долар","JPY_displayName":"Јапонски јен","CAD_symbol":"CA$","USD_displayName":"Американски долар","CNY_symbol":"CNY","GBP_displayName":"Британска Фунта","GBP_symbol":"GBP","AUD_symbol":"AUD","EUR_displayName":"Евро"});
