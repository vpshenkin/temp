/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/es/currency",{"HKD_displayName":"dólar hongkonés","CHF_displayName":"franco suizo","JPY_symbol":"JPY","CAD_displayName":"dólar canadiense","HKD_symbol":"HKD","CNY_displayName":"yuan","USD_symbol":"$","AUD_displayName":"dólar australiano","JPY_displayName":"yen","CAD_symbol":"CA$","USD_displayName":"dólar estadounidense","CNY_symbol":"CNY","GBP_displayName":"libra británica","GBP_symbol":"GBP","AUD_symbol":"AUD","EUR_displayName":"euro"});
