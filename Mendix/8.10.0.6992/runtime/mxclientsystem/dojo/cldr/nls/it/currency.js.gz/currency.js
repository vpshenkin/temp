/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/it/currency",{"HKD_displayName":"dollaro di Hong Kong","CHF_displayName":"franco svizzero","JPY_symbol":"JPY","CAD_displayName":"dollaro canadese","HKD_symbol":"HKD","CNY_displayName":"renminbi cinese","USD_symbol":"US$","AUD_displayName":"dollaro australiano","JPY_displayName":"yen giapponese","CAD_symbol":"CA$","USD_displayName":"dollaro statunitense","CNY_symbol":"CN¥","GBP_displayName":"sterlina inglese","GBP_symbol":"£","AUD_symbol":"A$","EUR_displayName":"euro"});
