/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/pt-pt/currency",{"HKD_displayName":"Dólar de Hong Kong","CHF_displayName":"Franco suíço","JPY_symbol":"JP¥","CAD_displayName":"Dólar canadiano","HKD_symbol":"HK$","CNY_displayName":"Yuan chinês","USD_symbol":"US$","AUD_displayName":"Dólar australiano","JPY_displayName":"Iene japonês","CAD_symbol":"CA$","USD_displayName":"Dólar dos Estados Unidos","EUR_symbol":"€","CNY_symbol":"CN¥","GBP_displayName":"Libra esterlina britânica","GBP_symbol":"£","AUD_symbol":"AU$","EUR_displayName":"Euro"});
