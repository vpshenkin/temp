/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sr/currency",{"HKD_displayName":"Хонгконшки долар","CHF_displayName":"Швајцарски франак","JPY_symbol":"¥","CAD_displayName":"Канадски долар","HKD_symbol":"HK$","CNY_displayName":"Кинески јуан","AUD_displayName":"Аустралијски долар","JPY_displayName":"Јапански јен","USD_displayName":"Амерички долар","EUR_symbol":"€","CNY_symbol":"CN¥","GBP_displayName":"Британска фунта","GBP_symbol":"£","AUD_symbol":"AUD","EUR_displayName":"Евро"});
