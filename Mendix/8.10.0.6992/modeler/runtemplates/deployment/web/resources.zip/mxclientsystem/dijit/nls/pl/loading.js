//>>built
define("dijit/nls/pl/loading",({loadingState:"Ładowanie...",errorState:"Niestety, wystąpił błąd"}));
