//>>built
define("dijit/nls/sk/loading",({loadingState:"Zavádza sa...",errorState:"Ľutujeme, ale vyskytla sa chyba"}));
