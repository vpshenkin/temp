//>>built
define("dijit/nls/ru/common",({buttonOk:"OK",buttonCancel:"Отмена",buttonSave:"Сохранить",itemClose:"Закрыть"}));
