//>>built
define("dijit/form/nls/id/Textarea",({iframeEditTitle:"edit area",iframeFocusTitle:"edit bingkai area"}));
