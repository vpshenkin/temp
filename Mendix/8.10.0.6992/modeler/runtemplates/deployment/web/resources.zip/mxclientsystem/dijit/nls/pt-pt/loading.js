//>>built
define("dijit/nls/pt-pt/loading",({loadingState:"A carregar...",errorState:"Lamentamos, mas ocorreu um erro"}));
